import React, { useMemo, useState } from 'react';
import { createRoot } from 'react-dom/client';
import {
  AreaChart, Area, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer,
  BarChart, Bar, ReferenceLine
} from 'recharts';
import {
  Activity, ArrowDownRight, ArrowUpRight, BarChart3, CalendarDays, ChevronDown,
  CircleDollarSign, Download, LayoutDashboard, Plus, Search, Settings2, Trash2,
  TrendingUp, Upload, X, Zap
} from 'lucide-react';
import './styles.css';

const today = () => new Date().toISOString().slice(0,10);
const fmt = (n, currency='USD') => new Intl.NumberFormat('en-US',{style:'currency',currency,maximumFractionDigits:2}).format(Number(n)||0);
const pct = n => `${(Number(n)||0).toFixed(1)}%`;
const seed = [];
function App(){
  const [trades,setTrades] = useState(()=>{try{return JSON.parse(localStorage.getItem('marko1-trades')||'[]')}catch{return []}});
  const [balance,setBalance] = useState(()=>Number(localStorage.getItem('marko1-balance')||10000));
  const [currency,setCurrency] = useState(()=>localStorage.getItem('marko1-currency')||'USD');
  const [page,setPage] = useState('Overview');
  const [modal,setModal] = useState(false);
  const [search,setSearch] = useState('');
  const [filter,setFilter] = useState('All trades');
  const [form,setForm] = useState({side:'Long',symbol:'',date:today(),entry:'',exit:'',qty:'1',fees:'0',notes:''});
  const [notice,setNotice] = useState('');
  const saveTrades = next => {setTrades(next);localStorage.setItem('marko1-trades',JSON.stringify(next));};
  const updateBalance = v => {setBalance(Number(v)||0);localStorage.setItem('marko1-balance',String(Number(v)||0));};
  const updateCurrency = v => {setCurrency(v);localStorage.setItem('marko1-currency',v);};
  const computed = useMemo(()=>{
    const ordered=[...trades].sort((a,b)=>a.date.localeCompare(b.date)||a.created-b.created);
    let eq=balance, peak=balance;
    const series=ordered.map((t,i)=>{
      const pnl=(t.side==='Long'?1:-1)*(Number(t.exit)-Number(t.entry))*Number(t.qty)-Number(t.fees||0);
      eq+=pnl; peak=Math.max(peak,eq);
      const dd=peak>0?((peak-eq)/peak)*100:0;
      return {...t,pnl,equity:eq,drawdown:dd,tradeNo:i+1};
    });
    const pnls=series.map(t=>t.pnl), wins=series.filter(t=>t.pnl>0), losses=series.filter(t=>t.pnl<0);
    const total=pnls.reduce((a,b)=>a+b,0), grossWin=wins.reduce((a,t)=>a+t.pnl,0), grossLoss=Math.abs(losses.reduce((a,t)=>a+t.pnl,0));
    const mean=pnls.length?total/pnls.length:0;
    const variance=pnls.length?pnls.reduce((s,p)=>s+(p-mean)**2,0)/pnls.length:0;
    const daily={};
    series.forEach(t=>{daily[t.date]=(daily[t.date]||0)+t.pnl});
    const days=Object.entries(daily).map(([date,pnl])=>({date,pnl})).sort((a,b)=>a.date.localeCompare(b.date));
    const long=series.filter(t=>t.side==='Long'), short=series.filter(t=>t.side==='Short');
    const dayAcc=side=>side.length?side.filter(t=>t.pnl>0).length/side.length*100:0;
    const ddValues=series.map(t=>t.drawdown);
    return {series,total,net:total,eq,peak,maxDD:Math.max(0,...ddValues),avgDD:ddValues.length?ddValues.reduce((a,b)=>a+b,0)/ddValues.length:0,
      wins,losses,winRate:series.length?wins.length/series.length*100:0,profitFactor:grossLoss?grossWin/grossLoss:(grossWin?Infinity:0),
      expectancy:mean,avgWin:wins.length?grossWin/wins.length:0,avgLoss:losses.length?losses.reduce((s,t)=>s+t.pnl,0)/losses.length:0,
      sharpe:variance>0?mean/Math.sqrt(variance):0,long,short,longAcc:dayAcc(long),shortAcc:dayAcc(short),days,
      bestDay:days.length?days.reduce((a,b)=>a.pnl>b.pnl?a:b):null,worstDay:days.length?days.reduce((a,b)=>a.pnl<b.pnl?a:b):null,
      avgTrade:mean, grossWin,grossLoss};
  },[trades,balance]);
  const visible = computed.series.filter(t=>(filter==='All trades'||(filter==='Winners'&&t.pnl>0)||(filter==='Losers'&&t.pnl<0)) &&
    `${t.symbol} ${t.side} ${t.date}`.toLowerCase().includes(search.toLowerCase())).reverse();
  const openNew = () => {setForm({side:'Long',symbol:'',date:today(),entry:'',exit:'',qty:'1',fees:'0',notes:''});setModal(true)};
  const addTrade = e => {
    e.preventDefault();
    if(form.entry===''||form.exit===''||Number(form.entry)<=0||Number(form.exit)<=0||Number(form.qty)<=0){setNotice('Entry, exit aur quantity valid numbers hone chahiye.');return;}
    const t={...form,id:crypto.randomUUID?crypto.randomUUID():String(Date.now()),created:Date.now(),entry:Number(form.entry),exit:Number(form.exit),qty:Number(form.qty),fees:Number(form.fees)||0,symbol:form.symbol.trim()||'—'};
    saveTrades([...trades,t]);setModal(false);setPage('Trades');setNotice('Trade saved successfully');setTimeout(()=>setNotice(''),2500);
  };
  const deleteTrade=id=>{if(confirm('Is trade ko delete karna hai?'))saveTrades(trades.filter(t=>t.id!==id));};
  const exportCSV=()=>{
    const headers=['date','side','symbol','entry','exit','qty','fees','pnl','notes'];
    const rows=computed.series.map(t=>[t.date,t.side,t.symbol,t.entry,t.exit,t.qty,t.fees,t.pnl,t.notes||'']);
    const csv=[headers,...rows].map(r=>r.map(v=>`"${String(v??'').replaceAll('"','""')}"`).join(',')).join('\n');
    const a=document.createElement('a');a.href=URL.createObjectURL(new Blob([csv],{type:'text/csv'}));a.download='marko1-trades.csv';a.click();URL.revokeObjectURL(a.href);
  };
  const importCSV=e=>{
    const file=e.target.files?.[0];if(!file)return;
    const reader=new FileReader();reader.onload=()=>{
      try{
        const lines=String(reader.result).trim().split(/\r?\n/);const headers=lines.shift().split(',').map(s=>s.replaceAll('"','').trim());
        const imported=lines.map((line,i)=>{const cols=line.match(/("([^"]|"")*"|[^,]*)(,|$)/g)||[];const vals=cols.map(s=>s.replace(/,$/,'').replace(/^"|"$/g,'').replaceAll('""','"'));const obj={};headers.forEach((h,j)=>obj[h]=vals[j]);return {id:crypto.randomUUID?crypto.randomUUID():String(Date.now()+i),created:Date.now()+i,date:obj.date||today(),side:obj.side==='Short'?'Short':'Long',symbol:obj.symbol||'—',entry:Number(obj.entry),exit:Number(obj.exit),qty:Number(obj.qty)||1,fees:Number(obj.fees)||0,notes:obj.notes||''};}).filter(t=>t.entry>0&&t.exit>0);
        saveTrades([...trades,...imported]);setNotice(`${imported.length} trades imported`);setTimeout(()=>setNotice(''),2500);
      }catch{setNotice('CSV import nahi ho paya. Exported Marko 1 CSV use karein.');}
    };reader.readAsText(file);e.target.value='';
  };
  const money = n => fmt(n,currency);
  const Metric=({label,value,sub,positive,icon:Icon})=><div className="metric"><div className="metric-top"><span>{label}</span><span className="metric-icon"><Icon size={16}/></span></div><div className={`metric-value ${positive===true?'green':positive===false?'red':''}`}>{value}</div>{sub&&<div className="metric-sub">{sub}</div>}</div>;
  const chartData = computed.series.map((t,i)=>({name:`#${i+1}`,equity:Number(t.equity.toFixed(2)),pnl:Number(t.pnl.toFixed(2)),date:t.date}));
  return <div className="app">
    <aside className="sidebar">
      <div className="brand"><div className="brand-mark"><Activity size={20}/></div><div><b>MARKO <span>1</span></b><small>TRADING JOURNAL</small></div></div>
      <div className="workspace"><div className="avatar">M</div><div><b>My trading desk</b><small>Personal workspace</small></div><ChevronDown size={15}/></div>
      <div className="nav-label">WORKSPACE</div>
      {[['Overview',LayoutDashboard],['Trades',BarChart3],['Analytics',TrendingUp]].map(([label,Icon])=><button key={label} className={`nav-item ${page===label?'active':''}`} onClick={()=>setPage(label)}><Icon size={17}/>{label}{label==='Trades'&&<span className="nav-count">{trades.length}</span>}</button>)}
      <div className="sidebar-bottom"><div className="plan-card"><div className="plan-icon"><Zap size={16}/></div><b>Your edge, quantified.</b><p>Track every trade. Improve every session.</p><button onClick={()=>setPage('Analytics')}>View performance <ArrowUpRight size={14}/></button></div><button className="nav-item" onClick={()=>setPage('Settings')}><Settings2 size={17}/>Settings</button><div className="profile"><div className="avatar">M</div><div><b>Trader</b><small>Local account</small></div><ChevronDown size={15}/></div></div>
    </aside>
    <main className="main">
      <header className="topbar"><div className="breadcrumb">Workspace <span>/</span> <b>{page}</b></div><div className="top-actions"><span className="local-pill"><span className="dot"></span> Data saved locally</span><button className="icon-btn" title="Export CSV" onClick={exportCSV}><Download size={17}/></button><button className="primary-btn" onClick={openNew}><Plus size={17}/> Log trade</button></div></header>
      <div className="content">
        {page==='Settings'?<><div className="page-heading"><div><div className="eyebrow">PREFERENCES</div><h1>Settings</h1><p>Apne journal ki base settings manage karein.</p></div></div><div className="settings-card"><label>Starting balance</label><p className="muted">Equity curve aur drawdown isi balance se calculate hote hain.</p><input type="number" value={balance} onChange={e=>updateBalance(e.target.value)}/><label>Display currency</label><select value={currency} onChange={e=>updateCurrency(e.target.value)}><option value="USD">USD — US Dollar</option><option value="INR">INR — Indian Rupee</option><option value="EUR">EUR — Euro</option><option value="GBP">GBP — Pound Sterling</option></select><div className="settings-note">Trades browser ke local storage mein save hote hain. Browser data clear karne se pehle CSV export kar lena.</div><button className="secondary-btn" onClick={exportCSV}><Download size={16}/> Export all trades (CSV)</button><label className="upload-btn"><Upload size={16}/> Import trades from CSV<input type="file" accept=".csv,text/csv" onChange={importCSV}/></label></div></>
        :<><div className="page-heading"><div><div className="eyebrow">YOUR PERFORMANCE, IN FOCUS</div><h1>{page==='Overview'?'Trading overview':page==='Trades'?'Trade history':'Performance analytics'}</h1><p>{page==='Overview'?'Your trading performance at a glance.':'A clear picture of your trading edge over time.'}</p></div><button className="secondary-btn date-btn"><CalendarDays size={16}/> All time <ChevronDown size={14}/></button></div>
          <div className="metrics-grid">
            <Metric label="Net P&L" value={money(computed.net)} sub={`${trades.length} closed trades`} positive={computed.net>0?true:computed.net<0?false:undefined} icon={CircleDollarSign}/>
            <Metric label="Win rate / Accuracy" value={pct(computed.winRate)} sub={`${computed.wins.length} wins · ${computed.losses.length} losses`} icon={Activity}/>
            <Metric label="Profit factor" value={computed.profitFactor===Infinity?'∞':computed.profitFactor.toFixed(2)} sub="Gross profit ÷ gross loss" positive={computed.profitFactor>=1?true:false} icon={TrendingUp}/>
            <Metric label="Expectancy / Trade" value={money(computed.expectancy)} sub="Average P&L per trade" positive={computed.expectancy>0?true:computed.expectancy<0?false:undefined} icon={Zap}/>
          </div>
          {page!=='Trades'&&<div className="charts-grid">
            <section className="panel equity-panel"><div className="panel-head"><div><h2>Equity curve</h2><p>Account balance over closed trades</p></div><span className="chart-legend"><i/> Equity</span></div>
              {chartData.length?<ResponsiveContainer width="100%" height={260}><AreaChart data={[{name:'Start',equity:balance},...chartData]} margin={{top:12,right:12,left:0,bottom:0}}><defs><linearGradient id="eqFill" x1="0" y1="0" x2="0" y2="1"><stop offset="0%" stopColor="#55d6a2" stopOpacity={.22}/><stop offset="100%" stopColor="#55d6a2" stopOpacity={0}/></linearGradient></defs><CartesianGrid stroke="#252a31" strokeDasharray="3 3" vertical={false}/><XAxis dataKey="name" stroke="#777f8b" tickLine={false} axisLine={false}/><YAxis stroke="#777f8b" tickLine={false} axisLine={false} width={72} tickFormatter={v=>new Intl.NumberFormat('en',{notation:'compact',maximumFractionDigits:1}).format(v)}/><Tooltip contentStyle={{background:'#171b21',border:'1px solid #303640',borderRadius:10,color:'#eef1f5'}} formatter={v=>[money(v),'Equity']}/><Area type="monotone" dataKey="equity" stroke="#55d6a2" strokeWidth={2.4} fill="url(#eqFill)" dot={false} activeDot={{r:4,fill:'#55d6a2',stroke:'#111'}}/></AreaChart></ResponsiveContainer>:<Empty icon={TrendingUp} title="Your equity curve starts here" text="Log your first trade to see your balance evolve."/>}
            </section>
            <section className="panel"><div className="panel-head"><div><h2>Trade P&L</h2><p>Profit and loss by trade</p></div><span className="muted small">Latest {Math.min(10,chartData.length)}</span></div>
              {chartData.length?<ResponsiveContainer width="100%" height={260}><BarChart data={chartData.slice(-10)} margin={{top:12,right:4,left:0,bottom:0}}><CartesianGrid stroke="#252a31" strokeDasharray="3 3" vertical={false}/><XAxis dataKey="name" stroke="#777f8b" tickLine={false} axisLine={false}/><YAxis stroke="#777f8b" tickLine={false} axisLine={false} width={62} tickFormatter={v=>new Intl.NumberFormat('en',{notation:'compact'}).format(v)}/><ReferenceLine y={0} stroke="#454c56"/><Tooltip contentStyle={{background:'#171b21',border:'1px solid #303640',borderRadius:10,color:'#eef1f5'}} formatter={v=>[money(v),'P&L']}/><Bar dataKey="pnl" radius={[4,4,0,0]} fill="#55d6a2" /></BarChart></ResponsiveContainer>:<Empty icon={BarChart3} title="No trades to chart yet" text="Add a trade to populate this chart."/>}
            </section>
          </div>}
          <div className="section-heading"><div><h2>{page==='Trades'?'All trades':'Performance breakdown'}</h2><p>{page==='Trades'?'Review and manage your trade log.':'More detail on risk, consistency and trade bias.'}</p></div>{page!=='Trades'&&<button className="text-btn" onClick={()=>setPage('Analytics')}>Full analytics <ArrowUpRight size={15}/></button>}</div>
          {page!=='Trades'&&<div className="metrics-grid secondary-metrics">
            <Metric label="Max drawdown" value={pct(computed.maxDD)} sub="Peak-to-trough decline" positive={false} icon={ArrowDownRight}/>
            <Metric label="Average drawdown" value={pct(computed.avgDD)} sub="Average trade-level drawdown" icon={Activity}/>
            <Metric label="Sharpe ratio*" value={computed.sharpe.toFixed(2)} sub="Per-trade, not annualized" icon={TrendingUp}/>
            <Metric label="Current equity" value={money(computed.eq)} sub={`Starting ${money(balance)}`} positive={computed.eq>=balance} icon={CircleDollarSign}/>
          </div>}
          {page==='Analytics'&&<><div className="two-col"><section className="panel"><div className="panel-head"><div><h2>Trade bias accuracy</h2><p>Win rate by direction</p></div></div><div className="bias-row"><div className="bias-name"><span className="side-dot long-dot"/>Long trades <b>{computed.long.length}</b></div><strong>{pct(computed.longAcc)}</strong></div><div className="progress"><span style={{width:`${computed.longAcc}%`}}/></div><div className="bias-row"><div className="bias-name"><span className="side-dot short-dot"/>Short trades <b>{computed.short.length}</b></div><strong>{pct(computed.shortAcc)}</strong></div><div className="progress short-progress"><span style={{width:`${computed.shortAcc}%`}}/></div><div className="mini-stats"><div><span>Average win</span><b className="green">{money(computed.avgWin)}</b></div><div><span>Average loss</span><b className="red">{money(computed.avgLoss)}</b></div></div></section><section className="panel"><div className="panel-head"><div><h2>Day-by-day results</h2><p>Best and worst trading day</p></div></div>{computed.bestDay?<><div className="day-result"><div className="day-icon good"><ArrowUpRight size={18}/></div><div><small>Best day</small><b>{computed.bestDay.date}</b></div><strong className="green">{money(computed.bestDay.pnl)}</strong></div><div className="day-result"><div className="day-icon bad"><ArrowDownRight size={18}/></div><div><small>Worst day</small><b>{computed.worstDay.date}</b></div><strong className={computed.worstDay.pnl<0?'red':'green'}>{money(computed.worstDay.pnl)}</strong></div><div className="day-result"><div className="day-icon neutral"><CalendarDays size={18}/></div><div><small>Profitable days</small><b>{computed.days.filter(d=>d.pnl>0).length} of {computed.days.length}</b></div><strong>{pct(computed.days.length?computed.days.filter(d=>d.pnl>0).length/computed.days.length*100:0)}</strong></div></>:<Empty icon={CalendarDays} title="Day stats appear here" text="Log trades with their dates to compare days."/>}</section></div><div className="panel footnote"><b>* Sharpe ratio note</b><p>Yeh simplified per-trade Sharpe hai: average trade P&L ÷ standard deviation of trade P&L. Isay annualized Sharpe na samjhein. Exact portfolio Sharpe ke liye consistent periodic returns aur risk-free rate chahiye.</p></div></>}
          <section className="panel trades-panel"><div className="panel-head trades-head"><div><h2>Recent trades</h2><p>{trades.length} total entries in your journal</p></div><div className="table-actions"><div className="searchbox"><Search size={15}/><input placeholder="Search trades..." value={search} onChange={e=>setSearch(e.target.value)}/></div><select value={filter} onChange={e=>setFilter(e.target.value)}><option>All trades</option><option>Winners</option><option>Losers</option></select><button className="icon-btn" onClick={exportCSV} title="Export CSV"><Download size={16}/></button></div></div>
            {visible.length?<div className="table-wrap"><table><thead><tr><th>DATE</th><th>SYMBOL</th><th>DIRECTION</th><th>ENTRY</th><th>EXIT</th><th>QTY</th><th>NET P&L</th><th>EQUITY</th><th></th></tr></thead><tbody>{visible.map(t=><tr key={t.id}><td className="date-cell">{t.date}</td><td className="symbol-cell">{t.symbol}</td><td><span className={`direction ${t.side.toLowerCase()}`}>{t.side==='Long'?<ArrowUpRight size={13}/>:<ArrowDownRight size={13}/>} {t.side}</span></td><td>{Number(t.entry).toLocaleString('en-US',{maximumFractionDigits:5})}</td><td>{Number(t.exit).toLocaleString('en-US',{maximumFractionDigits:5})}</td><td>{t.qty}</td><td className={t.pnl>0?'green':t.pnl<0?'red':''}>{money(t.pnl)}</td><td>{money(t.equity)}</td><td><button className="delete-btn" onClick={()=>deleteTrade(t.id)} title="Delete trade"><Trash2 size={15}/></button></td></tr>)}</tbody></table></div>:<Empty icon={BarChart3} title={trades.length?'No matching trades':'Your journal is ready'} text={trades.length?'Try another search or filter.':'Add your first Long or Short trade. Your analytics will calculate automatically.'} action={!trades.length?openNew:null}/>}
          </section>
          {page==='Overview'&&<p className="disclaimer">Metrics are calculated from the trades you enter. Instrument contract multipliers, slippage and taxes are not inferred; add applicable costs in Fees. This journal is for record-keeping, not financial advice.</p>}
        </>}
      </div>
    </main>
    {modal&&<div className="modal-backdrop" onMouseDown={e=>{if(e.target===e.currentTarget)setModal(false)}}><form className="trade-modal" onSubmit={addTrade}><div className="modal-head"><div><div className="eyebrow">TRADE ENTRY</div><h2>Log a trade</h2><p>Fill the basics. Marko 1 does the math.</p></div><button type="button" className="icon-btn" onClick={()=>setModal(false)}><X size={18}/></button></div><div className="side-toggle"><button type="button" className={form.side==='Long'?'chosen long-choice':''} onClick={()=>setForm({...form,side:'Long'})}><ArrowUpRight size={17}/> Long</button><button type="button" className={form.side==='Short'?'chosen short-choice':''} onClick={()=>setForm({...form,side:'Short'})}><ArrowDownRight size={17}/> Short</button></div><div className="form-grid"><label>Entry price *<input autoFocus type="number" step="any" min="0" required placeholder="e.g. 2345.50" value={form.entry} onChange={e=>setForm({...form,entry:e.target.value})}/></label><label>Exit price *<input type="number" step="any" min="0" required placeholder="e.g. 2360.00" value={form.exit} onChange={e=>setForm({...form,exit:e.target.value})}/></label><label>Symbol / Instrument<input placeholder="e.g. XAUUSD, NQ, BTC" value={form.symbol} onChange={e=>setForm({...form,symbol:e.target.value})}/></label><label>Trade date *<input type="date" required value={form.date} onChange={e=>setForm({...form,date:e.target.value})}/></label><label>Quantity / Lot size *<input type="number" min="0.000001" step="any" required value={form.qty} onChange={e=>setForm({...form,qty:e.target.value})}/></label><label>Fees / costs ({currency})<input type="number" min="0" step="any" value={form.fees} onChange={e=>setForm({...form,fees:e.target.value})}/></label></div><label className="notes-label">Notes (optional)<textarea rows="2" placeholder="Setup, mistakes, lessons..." value={form.notes} onChange={e=>setForm({...form,notes:e.target.value})}/></label>{form.entry!==''&&form.exit!==''&&<div className="preview-pnl"><span>Estimated net P&L</span><b className={(form.side==='Long'?1:-1)*(Number(form.exit)-Number(form.entry))*Number(form.qty||1)-Number(form.fees||0)>=0?'green':'red'}>{money((form.side==='Long'?1:-1)*(Number(form.exit)-Number(form.entry))*Number(form.qty||1)-Number(form.fees||0))}</b></div>}<div className="modal-actions"><button type="button" className="secondary-btn" onClick={()=>setModal(false)}>Cancel</button><button type="submit" className="primary-btn"><Plus size={16}/> Save trade</button></div></form></div>}
    {notice&&<div className="toast">{notice}</div>}
  </div>;
}
function Empty({icon:Icon,title,text,action}){return <div className="empty"><div className="empty-icon"><Icon size={22}/></div><b>{title}</b><p>{text}</p>{action&&<button className="primary-btn" onClick={action}><Plus size={16}/> Log first trade</button>}</div>}
createRoot(document.getElementById('root')).render(<App/>);